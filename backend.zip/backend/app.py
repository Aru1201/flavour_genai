import os
from fastapi import FastAPI
from pydantic import BaseModel
import vertexai
from vertexai.generative_models import GenerativeModel

# Initialize FastAPI
app = FastAPI()

# Initialize Vertex AI
PROJECT_ID = "your-gcp-project-id"
REGION = "us-central1"

vertexai.init(project=PROJECT_ID, location=REGION)

model = GenerativeModel("gemini-1.5-pro")

# Request Body Model
class RecipeRequest(BaseModel):
    ingredients: str
    cuisine: str
    diet: str
    cooking_time: str

@app.post("/generate-recipe")
async def generate_recipe(request: RecipeRequest):
    
    prompt = f"""
    Generate a detailed recipe using:
    Ingredients: {request.ingredients}
    Cuisine: {request.cuisine}
    Diet Type: {request.diet}
    Cooking Time: {request.cooking_time}
    
    Include:
    - Title
    - Ingredients list
    - Step-by-step instructions
    - Nutrition information
    - Cooking tips
    """

    response = model.generate_content(prompt)

    return {
        "recipe": response.text
    }

@app.get("/")
def root():
    return {"message": "Flavour Fusion Backend Running"}